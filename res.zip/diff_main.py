import re

# 假设 html 包含了 JavaScript 代码片段
html = """
            location.href = this.officeDomain + '/front/third/apps/seat/select?deptIdEnc=' + deptIdEnc
                + '&id=' + data.id
                + '&day=' + day
                + '&backLevel=2'
                + '&pageToken='
                + '9bf6d81424514f49852b2c61966b70d9'
                + '&fidEnc=' + deptIdEnc
"""

# 使用正则表达式提取 token
token = re.findall(r"'pageToken='\s*\+\s*'([^']*)'", html)[0] if re.findall(r"'pageToken='\s*\+\s*'([^']*)'", html) else ""

print(token)